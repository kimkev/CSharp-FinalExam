﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WCFServiceBMI
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IBMIService
    {
        public string calculateBMI(Person person)
        {
            double kg = person.weight;
            person.height = person.height / 100;
            double m2 = person.height * person.height;
            double bmi = Math.Round((kg / m2), 1);
            if (bmi >= 25.0)
            {
                return "OVERWEIGHT " + bmi.ToString();
            }
            else if (bmi <= 24.9 && bmi >= 18.5)
            {
                return "NORMAL " + bmi.ToString();
            }
            else
            {
                return "UNDERWEIGHT " + bmi.ToString();
            }
        }
    }
}
