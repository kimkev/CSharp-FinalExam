﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebAppBMIClient.ServiceReference1;


namespace WebAppBMIClient
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            ServiceReference1.BMIServiceClient client = new ServiceReference1.BMIServiceClient();
            Person person1 = new Person();
            person1.weight = double.Parse(txtWeight.Text);
            person1.height = double.Parse(txtHeight.Text);
            string[] words = client.calculateBMI(person1).Split(' ');
            string result = "Your BMI is " + words[1] + " and this is " + words[0];

            lblResult.Visible = true;
            lblResult.Text = result;
        }
    }
}